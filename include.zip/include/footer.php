<!-- Footer -->
<footer class="footer">
            <div class="container">
                <div class="subcrb52852">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="tehsub">
                                <h2>Subscribe to stay Informed</h2>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="subbox">
                                <input type="text" name="mailyor" placeholder="Your Mail">
                                <button class="buttn">Subscribe</button>
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="row"> 
                    <div class="col-md-3 col-sm-6">  
                        <div class="widget widget-out-link">
                            <h4 class="widget-title">RISK ASSURANCE</h4>
                            <ul class="one-half" style="margin-bottom: 30px;">
                                <li><a href="soc-audit-services.php">SOC (SSAE 18) Attestation</a></li>
                                <li><a href="iso-certification-services.php">ISO 27001</a></li>
                                <li><a href="hipaa-audit-certification-services.php">HIPAA</a></li>
                                <li><a href="hitrust-audit-certification-services.php">HITRUST Attestation</a></li>
                                <li><a href="uk-gdpr-audit-certification-services.php">GDPR</a></li>
                                <li><a href="aaf-audit-services.php">AAF 01/20</a></li>
                                <li><a href="pci-dss-audit-certification-services.php">PCI-DSS</a></li>
                                <li><a href="vapt.php">VAPT</a></li>
                                <!--<li><a href="vdpo.php">VDPO</a></li>-->
                                <li><a href="CMMI.php">CMMI</a></li>

                                <li><a href="fedramp.php">fedRAMP</a></li> 
                                <!--<li><a href="">SOX</a></li>-->
                                    
                            </ul> 
                            <h4 class="widget-title" >CROSS BORDER COMPLIANCES</h4>
                            <ul class="one-half">
                                <li><a href="transfer_pricing.php">Transfer Pricing</a></li>
                                <li><a href="fema.php">FEMA</a></li>
                                <!--<li><a href="">Expat Tax</a></li>-->
                                <!--<li><a href="">NRI</a></li>-->
                                <!--<li><a href="">Visa</a></li>-->    
                                               
                            </ul> 
                        </div>
                    </div><!-- /.col-md-3 --> 
                    <div class="col-md-3 col-sm-6">
                         <div class="widget widget-out-link">
                            <h4 class="widget-title">CPA SERVICES</h4>
                            <ul class="one-half">
                                <li><a href="Audit_Review_Compilation.php">Audit/Review/Compilation</a></li>
                                <!--<li><a href="https://accorppartners.com/ifrs-usgaap-ukgaap-services/index.php">IFRS/US GAAP/ UK GAAP</a></li>-->
                                <!--<li><a href="https://accorppartners.com/employee-retention-credit-services/index.php">ERC</a></li>-->
                                <li><a href="us-tax.php">US Tax/International Taxation</a></li> 
                                <li><a href="esop.php">ESOP</a></li>
                                                                   
                            </ul>
                             <h4 class="widget-title" style="margin-top:50px;    display: inline-block;">Incorporation</h4>
                            <ul class="one-half">
                                <li><a href="usa_incorporation.php">US Incorporation</a></li>
                                <li><a href="uk_incorporation.php">UK Incorporation</a></li>  
                                <li><a href="Dubai-Incorporation.php">Dubai Incorporation</a></li>
                                <!--<li><a href="">Bahamas Incorporation</a></li>-->
                                <!--<li><a href="">Cayman Island Incorporation</a></li>-->
                                <!--<li><a href="singapore_incorporation.php">Singapore Incorporation</a></li>-->
                                <li><a href="Entry-India.php">Entry India</a></li>
                            </ul> 
                        </div>
                    </div><!-- /.col-md-3 --> 
                    <div class="col-md-3 col-sm-6">  
                        <div class="widget widget-infomation">
                            <h3 class="logo-footer"><a href="#">ADDRESSES </a></h3>
                             
                            <div class="post-preview-wrap">
                             
                             <div class="for-add-ress">
                                 <h5>Head Office USA</h5>
                                 <p style="color:#fff;">5161 Lankershim Blvd, </p>
                                 <p style="color:#fff;"> North Hollywood, CA 91601, USA</p>
                             </div>
                             <div class="for-add-ress">
                                 <h5> UK Branch Office</h5>
                                 <p style="color:#fff;">Office 571
                                    182-184 High Street
                                    North,</p>
                                                                     <p style="color:#fff;">East Ham,
                                    London
                                    E6 2JA.
                                    UK</p>
                                    <p style="color:#fff;"><i class="fa fa-phone" aria-hidden="true" style="color:#fff;margin-right:10px;"></i> +447721703158</p>
                             </div>
                             <div class="for-add-ress">
                                 <h5>Canada Branch Office</h5>
                                 <p style="color:#fff;">419 Richmond street London</p>
                                 <p style="color:#fff;">Ontario N6A :3C8</p>
                             </div>
                             <div class="for-add-ress">
                                 <h5>India Branch Office</h5>
                                 <p style="color:#fff;">901/909, ITL Twin Tower, </p>
                                 <p style="color:#fff;">BO9, NSP Pitam Pura, Delhi, 110034</p>
                             </div>
                             <div class="for-add-ress">
                                 <h5>Spain Branch Office</h5>
                                 <p style="color:#fff;">Avenida Pilar Mir 59. Rivas - Vaciamadrid </p>
                                 <!--<p style="color:#fff;">BO9, NSP Pitam Pura, Delhi, 110034</p>-->
                             </div>
                    </div>         
                        </div>         
                    </div><!-- /.col-md-3 --> 

                    
                    <div class="col-md-3 col-sm-6">
                        <div class="widget widget-letter">
                            <h4 class="widget-title">Connect</h4>
                            <div class="foren">
                              <ul class="d-sadsa">
                               
                                <li><img src="assets/images/usflag.jpg"><span><a href="tel:+1 (818) 273-7618">+1 818 527 4945</a></span></li>
                                 <li><img src="assets/images/indiaflag.svg"><span><a href="tel:+91 99682 97717">+91 99682 97717</a></span></li>
                                <li><img src="assets/images/UK-f.jpg"><span><a href="tel:+447721703158">+447721703158</a></span></li>
                                <li><img src="assets/images/spain-flag.png"><span><a href="tel:+34 604879068">+34 604879068</a></span></li>
                              </ul>
                            </div>
                                                          
                        </div>
                        <ul class="rd-navbar-aside-group list-units tklo31">
                    
                      <li><a href="https://www.linkedin.com/company/accorp-partners/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://www.instagram.com/accorppartners/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                          <li><a href="https://twitter.com/accorppartners" target="_blank"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="https://www.youtube.com/channel/UCaXAPT1n5QGPkrxSS__RIPg" target="_blank"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li><a href="https://www.youtube.com/channel/UCaXAPT1n5QGPkrxSS__RIPg" target="_blank">
                    </a><li><a href="https://www.youtube.com/channel/UCaXAPT1n5QGPkrxSS__RIPg" target="_blank"></a><a href="https://www.facebook.com/accorpfinancialconsultant/" target="_blank"><i class="fa fa-facebook"></i></a></li>
          
                  </ul>
                    </div><!-- /.col-md-3 -->
                </div><!-- /.row -->    
                <div class="line"><hr></div>
            </div><!-- /.container -->
        </footer>

        <!-- Bottom -->
        <div class="bottom">
            <div class="container">
                <div class="copyright"> 
                    <p>@2023 <a href="index.php">Accorp Partner INC</a>. All rights reserved.
                    </p>
                </div>
                <ul class="social-links">
                    <li><a href="#" target="_blank">Privacy Policy</a></li> 
                    <li><a href="#">Site Map</a></li>
                </ul>                   
            </div><!-- /.container -->
        </div><!-- bottom -->    
</div>   
 