<div class="top-2323">
<div class="top-number">
    <div class="container-fluid">
        <ul class="numheiks2">
            <li><a href="#"><img src="assets/images/flg-1.png"> <span>+1 818 527 4945</span></a></li>
            <li><a href="#"><img src="assets/images/flg-2.png"> <span>+44 7721 703158</span></a></li>
            <li><a href="#"><img src="assets/images/flg-3.png"> <span>+91 9968297717</span></a></li>
        </ul>
    </div>
</div>
<header id="header" class="header header-classic">
    <div class="container-fluid">
        <div class="row">                 
            <div class="header-wrap">
                <div class="logo1">
                    <div id="logo" class="logo mgl2">
                        <a href="index.php" rel="home" class="white">
                            <img src="assets/images/accorp.png" alt="image">
                        </a>
                        <!-- <a href="#" rel="home" class="black">
                            <img src="assets/images/accorp-logo-black.png" alt="image">
                        </a>                                 -->
                    </div><!-- /.logo -->
                    <div class="btn-menu"id="toggle">
                        <span onclick="myFunction()"></span>
                    </div><!-- //mobile menu button -->
                </div>
                        <div class="menu-1">
                            <div class="nav-wrap">                            
                                <nav id="mainnav" class="mainnav">
                                    <ul class="menu"> 
                                        <li class="active"><a href="index.php">Home</a>
                                        </li>
                                        <li><a href="about.php">About us</a>
                                        </li>
                                        <li class="ser-12se3"><a href="#">Services<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                            <ul class="submenu"> 
                                               <div class="container">
                                                   <div class="row">
                                                       <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                           <div class="serlist-1233">
                                                               <h3>RISK ASSURANCE</h3>
                                                               <ul class="one-123">
                                                                    <li><a href="soc-audit-services.php">SOC (SSAE 18) Attestation</a></li>
                                                                    <li><a href="iso-certification-services.php">ISO 27001</a></li>
                                                                    <li><a href="hipaa-audit-certification-services.php">HIPAA</a></li>
                                                                    <li><a href="hitrust-audit-certification-services.php">HITRUST Attestation</a></li>
                                                                    <li><a href="uk-gdpr-audit-certification-services.php">GDPR</a></li>
                                                                   
                                                                    <li><a href="pci-dss-audit-certification-services.php">PCI-DSS</a></li>
                                                                    <li><a href="vapt.php">VAPT</a></li>
                                                                    <!--<li><a href="vdpo.php">VDPO</a></li>-->
                                                                    <li><a href="CMMI.php">CMMI</a></li>
                                                                 
                                                                    <li><a href="fedramp.php">FEDRAMP</a></li> 
                                                                     <li><a href="aaf-audit-services.php">AAF 01/20</a></li>
                                                                    <li><a href="map.php">SOX</a></li>
                                                               </ul>
                                                           </div>
                                                       </div>
                                                       <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                           <div class="serlist-1233">
                                                               <h3>CROSS BORDER COMPLIANCES </h3>
                                                               <ul class="one-123">
                                                                   <li><a href="transfer_pricing.php">Transfer Pricing</a></li>
                                                                   <li><a href="fema.php">FEMA</a></li>
                                                                   <!--<li><a href="">Expat Tax</a></li>-->
                                                                   <!--<li><a href="">NRI</a></li>-->
                                                                    <!--<li><a href="">Visa</a></li>-->
                                                                    <h3>INCORPORATION </h3>
                                                                    <li><a href="usa_incorporation.php">US Incorporation</a></li>
                                                                    <li><a href="uk_incorporation.php">UK Incorporation</a></li>  
                                                                    <li><a href="Dubai-Incorporation.php">Dubai Incorporation</a></li>
                                                                    <!--<li><a href="">Bahamas Incorporation</a></li>-->
                                                                    <!--<li><a href="">Cayman Island Incorporation</a></li>-->
                                                                    <!--<li><a href="singapore_incorporation.php">Singapore Incorporation</a></li>-->
                                                                    <li><a href="Entry-India.php">India Incorporation</a></li>
                                                               </ul>
                                                           </div>
                                                       </div>
                                                       
                                                       <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                           <div class="serlist-1233">
                                                               <h3>CPA SERVICES</h3>
                                                               <ul class="one-123">
                                                                  <li><a href="Audit_Review_Compilation.php">Audit/Review/Compilation</a></li>
                                                                   <!--<li><a href="https://accorppartners.com/ifrs-usgaap-ukgaap-services/index.php">IFRS/US GAAP/ UK GAAP</a></li>-->
                                                                   <!--<li><a href="https://accorppartners.com/employee-retention-credit-services/index.php">ERC</a></li>-->
                                                                     
                                                                   <li><a href="us-tax.php">US Tax</a></li> 
                                                                   <li><a href="esop.php">ESOP</a></li>
                                                                   
                                                               </ul>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                            </ul> 
                                        </li>
                                        <li><a href="all_blogs.php">Blog</a>
                                        </li>
                                        <li><a href="https://accorppartners.com/partner-with-us.php">Partner Us</a></li>
                                        
                                        </li>    
                                        <li><a href="contact-us.php">Contact us</a>
                                        </li>
                                    </ul><!-- /.menu -->
                                </nav><!-- /.mainnav --> 
                            </div><!-- /.nav-wrap -->
                        </div> 
                        <div class="sol-11">
                            <div class="allsol123">
                                <ul>
                                    <!-- <li> <div id="google_translate_element"></div></li> -->
                                    <li class="call-point"><a href="https://go.oncehub.com/AccorpPartners" target="_blank"><i class="phone"></i>Schedule A Call Today</a></li>
                                   
                                </ul>
                            </div>
                             
                        </div>                     
                    </div><!-- /.header-inner -->                 
                </div><!-- /.row -->
            </div>
        </header><!-- /.header -->

        </div>